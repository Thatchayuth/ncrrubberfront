import { Component } from '@angular/core';

@Component({
  selector: 'app-history-news',
  imports: [],
  templateUrl: './history-news.html',
  styleUrl: './history-news.scss'
})
export class HistoryNews {

}
